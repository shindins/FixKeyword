#ifndef KEYWORD_MAIN_H_
#define KEYWORD_MAIN_H_

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <exception>
#include <algorithm>
#include <map>

#include "keywordfixer.h"
#include "config.h"
#include "util.h"


#endif // !KEYWORD_MAIN_H_

